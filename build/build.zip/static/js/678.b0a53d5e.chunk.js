"use strict";(self.webpackChunkchat=self.webpackChunkchat||[]).push([[678],{19678:function(a,c,e){e.r(c);var t=e(94227);c.default=t.g}}]);
//# sourceMappingURL=678.b0a53d5e.chunk.js.map